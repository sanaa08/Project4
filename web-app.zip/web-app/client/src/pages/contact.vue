<template>
  <div>
    <!-- Sticky Navigation Bar -->
    <nav
      class="bg-pink-50 p-4 text-black fixed w-full top-0 z-10 flex flex-col items-center justify-center shadow-2xl rounded-full"
    >
      <!-- Logo/Brand (you can replace this with your logo) -->
      <div class="flex flex-col items-center mb-4">
        <div class="flex items-center mb-2">
          <img
            src="../assets/logo.jpg"
            alt="Logo"
            class="h-8 w-auto mr-2 rounded-full"
          />
          <div class="text-3xl font-bold">Tabaku Event</div>
        </div>
      </div>
      <div class="flex items-center font-mono">
        <router-link to="/home" class="hover:underline mr-4 hover:text-blue-400"
          >Rreth nesh</router-link
        >
        <div
          class="relative"
          @mouseover="openDropdown"
          @mouseleave="closeDropdown"
        >
          <router-link
            to="/service-page-1"
            class="hover:underline mr-4 hover:text-blue-400"
            >Sherbimet</router-link
          >
          <div
            v-show="showDropDown"
            @mouseover="openDropdown"
            @mouseleave="closeDropdown"
            class="absolute mt-2 bg-white border border-gray-300 p-2 rounded-md shadow-md"
          >
            <router-link
              to="/service-page-1"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
              >Dasem</router-link
            >
            <router-link
              to="/service-page-2"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
              >Ditelindje</router-link
            >
            <router-link
              to="/service-page-3"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
              >Ambjente Jashte</router-link
            >
          </div>
        </div>
        <router-link to="/contact" class="hover:underline hover:text-blue-400"
          >Kontakt</router-link
        >
      </div>
    </nav>

    <!-- Company Information Section -->
    <section class="bg-pink-50 p-8 mt-32 shadow-2xl">
      <div
        class="max-w-6xl mx-auto flex flex-col lg:flex-row items-center lg:items-start"
      >
        <div class="lg:w-1/2 mb-4 lg:mr-20 text-center">
          <div>
            <h2 class="text-2xl font-bold mb-4 font-mono">Na kontaktoni</h2>
            <form @submit.prevent="submitForm">
              <div class="mb-4">
                <label
                  for="name"
                  class="block text-sm font-medium text-gray-700 font-mono"
                  >Emri</label
                >
                <input
                  v-model="formData.name"
                  type="text"
                  id="name"
                  name="name"
                  required
                  class="mt-1 p-2 w-full border rounded-md shadow-md"
                />
              </div>

              <div class="mb-4">
                <label
                  for="email"
                  class="block text-sm font-medium text-gray-700 font-mono"
                  >Email</label
                >
                <input
                  v-model="formData.email"
                  type="email"
                  id="email"
                  name="email"
                  required
                  class="mt-1 p-2 w-full border rounded-md shadow-md"
                />
              </div>
              <div class="mb-4">
                <label
                  for="phone"
                  class="block text-sm font-medium text-gray-700 font-mono"
                  >Numer telefoni</label
                >
                <div class="flex items-center">
                  <select
                    v-model="formData.countryCode"
                    class="mt-1 p-2 border rounded-md shadow-md"
                  >
                    <!-- Add your country codes here -->
                    <option value="+355">+355</option>
                    <option value="+44">+44</option>
                    <option value="+39">+39</option>
                    <option value="+30">+30</option>
                    <!-- Add more options as needed -->
                  </select>
                  <input
                    v-model="formData.phoneNumber"
                    type="text"
                    id="phone"
                    name="phone"
                    required
                    class="mt-1 p-2 flex-1 border rounded-md shadow-md"
                  />
                </div>
              </div>

              <div class="mb-4">
                <label
                  for="message"
                  class="font-mono block text-sm font-medium text-gray-700"
                  >Mesazhi</label
                >
                <textarea
                  v-model="formData.message"
                  id="message"
                  name="message"
                  rows="4"
                  required
                  class="mt-1 p-2 w-full border rounded-md shadow-md"
                ></textarea>
              </div>

              <button
                type="submit"
                class="bg-neutral-200 text-black p-2 rounded-md font-mono cursor-progress"
              >
                Dergo mesazhin
              </button>
            </form>
          </div>
        </div>

        <div class="lg:w-1/2 ml-8 mt-24">
          <img
            src="../assets/events.jpg"
            alt="Company"
            class="w-full h-auto lg:h-60 rounded-md shadow-2xl"
          />
        </div>
      </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-pink-50 p-8 text-center border border-grey">
      <div
        class="max-w-6xl mx-auto flex flex-col lg:flex-row justify-center items-center"
      >
        <!-- Column 1: Company Logo and Name -->
        <div class="lg:w-1/4 mb-4 lg:mb-0 flex flex-col items-center">
          <div class="flex items-center mb-2">
            <img
              src="../assets/logo.jpg"
              alt="Logo"
              class="h-8 w-auto mr-2 rounded-full"
            />
            <div class="text-3xl font-bold">Tabaku Event</div>
          </div>
          <!-- Additional Company Info if needed -->
        </div>

        <!-- Column 2: Navigation Links -->
        <div class="lg:w-1/4 mb-4 lg:mb-0 font-mono">
          <h3 class="text-xl font-bold mb-2">Quick Links</h3>
          <ul>
            <li><a class="hover:text-blue-400" href="/home">Rreth nesh</a></li>
            <li>
              <a class="hover:text-blue-400" href="/service-page-1"
                >Sherbimet</a
              >
            </li>
            <li><a class="hover:text-blue-400" href="/contact">Kontakt</a></li>
          </ul>
        </div>

        <!-- Column 3: Contact Details -->
        <div class="lg:w-1/4 font-mono">
          <h3 class="text-xl font-bold mb-2">Kontakt</h3>
          <p>
            <i class="fas fa-envelope mr-2"></i> Email: info@tabakuevent.com
          </p>
          <p><i class="fas fa-phone-alt mr-2"></i> Phone: +355 696157649</p>
          <p><i class="fas fa-map-marker-alt mr-2"></i> Pajove, Elbasan</p>
        </div>
      </div>

      <!-- Additional styling if needed -->
    </footer>
  </div>
</template>

<script>
import backgroundImage from "../assets/w.jpg";

export default {
  name: "Contact",
  data() {
    return {
      backgroundImage,
      formData: {
        name: "",
        email: "",
        message: "",
      },
      submitFormMessage: "",
      showDropDown: false,
      dropdownTimer: null,
    };
  },
  methods: {
    openDropdown() {
      clearTimeout(this.dropdownTimer);
      this.showDropDown = true;
    },
    closeDropdown() {
      this.dropdownTimer = setTimeout(() => {
        this.showDropDown = false;
      }, 1000); // Adjust the duration (in milliseconds) you want the dropdown to stay visible
    },
    keepDropdownOpen() {
      // Do nothing to keep the dropdown open when clicking on a service link
    },
    async submitForm() {
      this.submitFormMessage = "";

      try {
        const response = await fetch(
          "http://localhost:3001/api/auth/contact/save-message",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              name: this.formData.name,
              email: this.formData.email,
              phoneNumber: this.formData.phoneNumber,
              message: this.formData.message,
            }),
          }
        );

        const responseData = await response.json(); // Parse the response JSON

        if (response.ok) {
          this.submitFormMessage = "Message sent successfully!";
        } else {
          this.submitFormMessage = `Failed to send message: ${responseData.message}`;
        }
      } catch (error) {
        console.error("Error during form submission:", error);
        this.submitFormMessage =
          "Error during form submission. Please try again.";
      }
    },
  },
  // ... (your other options, components, etc.)
};
</script>

<style scoped>
/* ... (your component-specific styles) ... */
</style>
