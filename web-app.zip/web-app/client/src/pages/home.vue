<template>
  <div>
    <!-- Sticky Navigation Bar -->
    <nav
      class="bg-pink-50 p-4 text-black fixed w-full top-0 z-10 flex flex-col items-center justify-center shadow-2xl rounded-full"
    >
      <!-- Logo/Brand (you can replace this with your logo) -->
      <div class="flex flex-col items-center mb-4">
        <div class="flex items-center mb-2">
          <img
            src="../assets/logo.jpg"
            alt="Logo"
            class="h-8 w-auto mr-2 rounded-full"
          />
          <div class="text-3xl font-bold">Tabaku Event</div>
        </div>
      </div>
      <div class="flex items-center font-mono">
        <router-link to="/home" class="hover:underline mr-4 hover:text-blue-400"
          >Rreth nesh</router-link
        >
        <div
          class="relative"
          @mouseover="openDropdown"
          @mouseleave="closeDropdown"
        >
          <router-link
            to="/service-page-1"
            class="hover:underline mr-4 hover:text-blue-400"
            >Sherbimet</router-link
          >
          <div
            v-show="showDropDown"
            @mouseover="openDropdown"
            @mouseleave="closeDropdown"
            class="absolute mt-2 bg-white border border-gray-300 p-2 rounded-md shadow-md"
          >
            <router-link
              to="/service-page-1"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
              >Dasem</router-link
            >
            <router-link
              to="/service-page-2"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
            >
              Ditelindje</router-link
            >
            <router-link
              to="/service-page-3"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
            >
              Ambjente Jashte</router-link
            >
          </div>
        </div>
        <router-link to="/contact" class="hover:underline hover:text-blue-400"
          >Kontakt</router-link
        >
      </div>
    </nav>

    <!-- Section with Background Picture -->
    <section
      class="relative h-screen flex items-center background-size no-repet"
    >
      <video autoplay muted loop playsinline class="w-full h-full object-cover">
        <source src="../assets/video1.MP4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </section>

    <!-- Video Section -->
    <!-- <section class="relative min-h-screen bg-cover bg-center">
      <div class="aspect-w-16 aspect-h-9">
        
        <video
          autoplay
          muted
          loop
          playsinline
          class="w-full h-full object-cover"
        >
          <source src="../assets/video.MP4" type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </div>
      
    </section> -->

    <!-- Company Information Section -->
    <section class="bg-pink-50 p-8 mt-[-2] shadow-2xl">
      <div
        class="max-w-6xl mx-auto flex flex-col lg:flex-row items-center lg:items-start"
      >
        <!-- Paragraph about the company -->
        <div class="lg:w-1/2 mb-4 lg:mr-20 text-center font-mono">
          <p>
            Me mbi 5 vjet përvojë në fushën e dasmave dhe eventeve te ndryshme,
            ne vazhdojmë të krenohemi për aftësinë tonë në realizimin e vizionit
            tuaj dhe në transformimin e hapësirave për të krijuar kujtime që do
            të mbeten gjatë. Synimi kryesor dhe vizioni ynë është të ndërtojmë
            një ndikim pozitiv në jetën e njerëzve.
          </p>
          <p class="mt-4 font-bold font-mono">
            Jemi të përkushtuar për të realizuar vizionin tuaj dhe për të
            krijuar një përvojë vërtetë të paharrueshme!
          </p>
        </div>

        <!-- Picture on the left -->

        <div class="lg:w-1/2 ml-8">
          <img
            src="../assets/events.jpg"
            alt="Company"
            class="w-full h-auto lg:h-60 rounded-md shadow-2xl"
          />
        </div>
      </div>
    </section>

    <section class="bg-white p-8">
      <h2 class="text-2xl font-bold mb-4 text-center">ORGANIZONI ME NE</h2>
      <p class="text-center mb-4 font-mono">
        KRIJO NJË PERVOJË UNIKE ME SHËRBIMIN TONË
      </p>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <!-- Service 1 -->
        <router-link to="/service-page-1" class="text-black no-underline">
          <div class="flex flex-col items-center">
            <img
              src="../assets/wedding2.jpg"
              alt="Service 1"
              class="w-64 h-72 mb-2 rounded-md shadow-2xl transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300"
            />
            <p
              class="font-mono text-center rounded-md text-black mt-4 hover:text-blue-400"
            >
              Dekor dasem
            </p>
          </div>
        </router-link>

        <!-- Service 2 -->
        <router-link to="/service-page-2" class="text-black no-underline">
          <div class="flex flex-col items-center">
            <img
              src="../assets/birthday.jpg"
              alt="Service 2"
              class="w-64 h-72 mb-2 rounded-md shadow-2xl transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300"
            />
            <p
              class="font-mono text-center rounded-md text-black mt-4 hover:text-blue-400"
            >
              Dekor ditelindjeje
            </p>
          </div>
        </router-link>

        <!-- Service 3 -->
        <router-link to="/service-page-3" class="text-black no-underline">
          <div class="flex flex-col items-center">
            <img
              src="../assets/o7.jpg"
              alt="Service 3"
              class="w-64 h-72 mb-2 rounded-md shadow-2xl transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300"
            />
            <p
              class="font-mono text-center rounded-md text-black mt-4 hover:text-blue-400"
            >
              <!--border-double border-4 border-teal-500 -->
              Dekor per ambjente jashte
            </p>
          </div>
        </router-link>
      </div>
    </section>
    <section class="bg-pink-50 p-14 relative shadow-xl">
      <div
        class="flex flex-col items-center justify-center text-center relative"
      >
        <p class="mb-4 font-mono">
          Jemi këtu për t'ju ndihmuar dhe për të biseduar me ju rreth çdo
          detaji. Mos ngurroni të na kontaktoni për çdo pyetje, kërkesë ose
          konsultim. Presim me padurim të dëgjojmë nga ju dhe të ndihmojmë në
          çdo mënyrë të mundshme.
        </p>

        <!-- Get in Touch Button -->
        <router-link
          to="/contact"
          class="bg-neutral-200 text-black px-4 py-2 rounded-md border mx-auto font-mono"
        >
          Na kontaktoni
        </router-link>
      </div>
    </section>

    <!-- Instagram Gallery Section -->
    <section class="bg-white p-8">
      <h2 class="text-2xl font-bold mb-4 text-center font-mono">
        Ndiqni rrugetimin tone
      </h2>

      <!-- Gallery Section -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <!-- Instagram Post 1 -->
        <div class="instagram-post-container">
          <a
            href="https://www.instagram.com/p/CzOKlu1orjY/?utm_source=ig_embed&amp;utm_campaign=loading"
            target="_blank"
            class="instagram-post"
          >
            <img
              src="../assets/instagram1.jpg"
              alt="Instagram Post 1"
              class="w-full h-full object-cover rounded-md shadow-2xl"
            />
          </a>
        </div>

        <!-- Instagram Post 2 -->
        <div class="instagram-post-container">
          <a
            href="https://www.instagram.com/p/Cv6q6rvoR-1/?utm_source=ig_embed&amp;utm_campaign=loading"
            target="_blank"
            class="instagram-post"
          >
            <img
              src="../assets/instagram2.jpg"
              alt="Instagram Post 2"
              class="w-full h-full object-cover rounded-md shadow-2xl"
            />
          </a>
        </div>

        <!-- Instagram Post 3 -->
        <div class="instagram-post-container">
          <a
            href="https://www.instagram.com/p/Cv0dQ81oRQQ/?utm_source=ig_embed&amp;utm_campaign=loading"
            target="_blank"
            class="instagram-post"
          >
            <img
              src="../assets/instagram3.png"
              alt="Instagram Post 3"
              class="w-full h-full object-cover rounded-md shadow-2xl"
            />
          </a>
        </div>

        <!-- Instagram Post 4 -->
        <div class="instagram-post-container">
          <a
            href="https://www.instagram.com/p/CtFZvojoR2T/?utm_source=ig_embed&amp;utm_campaign=loading"
            target="_blank"
            class="instagram-post"
          >
            <img
              src="../assets/instagram4.png"
              alt="Instagram Post 4"
              class="w-full h-full object-cover rounded-md shadow-2xl"
            />
          </a>
        </div>
      </div>
    </section>

    <!-- Footer Section -->
    <footer class="bg-pink-50 p-8 text-center">
      <div
        class="max-w-6xl mx-auto flex flex-col lg:flex-row justify-center items-center"
      >
        <!-- Column 1: Company Logo and Name -->
        <div class="lg:w-1/4 mb-4 lg:mb-0 flex flex-col items-center">
          <div class="flex items-center mb-2">
            <img
              src="../assets/logo.jpg"
              alt="Logo"
              class="h-8 w-auto mr-2 rounded-full"
            />
            <div class="text-3xl font-bold">Tabaku Event</div>
          </div>
          <!-- Additional Company Info if needed -->
        </div>

        <!-- Column 2: Navigation Links -->
        <div class="lg:w-1/4 mb-4 lg:mb-0 font-mono">
          <h3 class="text-xl font-bold mb-2">Quick Links</h3>
          <ul>
            <li><a class="hover:text-blue-400" href="/home">Rreth nesh</a></li>
            <li>
              <a class="hover:text-blue-400" href="/service-page-1"
                >Sherbimet</a
              >
            </li>
            <li><a class="hover:text-blue-400" href="/contact">Kontakt</a></li>
          </ul>
        </div>

        <!-- Column 3: Contact Details -->
        <div class="lg:w-1/4 font-mono">
          <h3 class="text-xl font-bold mb-2">Kontakt</h3>
          <p>
            <i class="fas fa-envelope mr-2"></i> Email: info@tabakuevent.com
          </p>
          <p><i class="fas fa-phone-alt mr-2"></i> Phone: +355 696157649</p>
          <p><i class="fas fa-map-marker-alt mr-2"></i> Pajove, Elbasan</p>
        </div>
      </div>

      <!-- Additional styling if needed -->
    </footer>
  </div>
</template>

<script>
import backgroundImage from "../assets/tabaku-event.jpg";
import Image from "../assets/decoration.jpg";
import InstagramPost from "../components/InstagramPost.vue";

export default {
  name: "Home",
  data() {
    return {
      backgroundImage,
      Image,
      showDropDown: false,
      dropdownTimer: null,
    };
  },
  methods: {
    openDropdown() {
      clearTimeout(this.dropdownTimer);
      this.showDropDown = true;
    },
    closeDropdown() {
      this.dropdownTimer = setTimeout(() => {
        this.showDropDown = false;
      }, 500); // Adjust the duration (in milliseconds) you want the dropdown to stay visible
    },
    keepDropdownOpen() {
      // Do nothing to keep the dropdown open when clicking on a service link
    },
  },
  components: {
    InstagramPost,
  },
};
</script>

<style scoped>
/* Add component-specific styles here */
</style>
