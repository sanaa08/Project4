<template>
  <!-- Add this to the head of your HTML file -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    integrity="sha384-Vkoo8q4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBnyFhSZZgfaW2DO4AeljlP5"
    crossorigin="anonymous"
  />

  <div>
    <!-- Sticky Navigation Bar -->
    <nav
      class="bg-pink-50 p-4 text-black fixed w-full top-0 z-10 flex flex-col items-center justify-center shadow-2xl rounded-full"
    >
      <!-- Logo/Brand (you can replace this with your logo) -->
      <div class="flex flex-col items-center mb-4">
        <div class="flex items-center mb-2">
          <img
            src="../assets/logo.jpg"
            alt="Logo"
            class="h-8 w-auto mr-2 rounded-full"
          />
          <div class="text-3xl font-bold">Tabaku Event</div>
        </div>
      </div>
      <div class="flex items-center font-mono">
        <router-link to="/home" class="hover:underline mr-4 hover:text-blue-400"
          >Rreth nesh</router-link
        >
        <div
          class="relative"
          @mouseover="openDropdown"
          @mouseleave="closeDropdown"
        >
          <router-link
            to="/service-page-1"
            class="hover:underline mr-4 hover:text-blue-400"
            >Sherbimet</router-link
          >
          <div
            v-show="showDropDown"
            @mouseover="openDropdown"
            @mouseleave="closeDropdown"
            class="absolute mt-2 bg-white border border-gray-300 p-2 rounded-md shadow-md"
          >
            <router-link
              to="/service-page-1"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
              >Dasem</router-link
            >
            <router-link
              to="/service-page-2"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
            >
              Ditelindje</router-link
            >
            <router-link
              to="/service-page-2"
              class="block py-2 px-4 hover:bg-pink-100 hover: rounded"
              @click="keepDropdownOpen"
            >
              Ambjente Jashte</router-link
            >
          </div>
        </div>
        <router-link to="/contact" class="hover:underline hover:text-blue-400"
          >Kontakt</router-link
        >
      </div>
    </nav>

    <!-- Section with Background Picture -->
    <section
      class="relative h-screen bg-cover bg-center flex items-center background-size"
      :style="{
        backgroundImage: 'url(' + backgroundImage + ')',
        backgroundSize: '100%',
      }"
    >
      <div class="text-white text-4xl font-bold mx-auto">Dekor Dasem</div>
    </section>

    <section class="relative bg-pink-50 p-8">
      <div class="flex justify-center w-full">
        <!-- Picture on the left -->
        <!-- <div class="mb-4 lg:mb-0 overflow-hidden">  class="max-w-6xl mx-auto flex flex-col lg:flex-row items-center lg:items-start"
          <img
            src="../assets/events.jpg"
            alt="Your Image"
            class="w-full h-auto lg:h-60 rounded-md shadow-md"
          />
        </div> -->

        <!-- Paragraph on the right with white background -->
        <div
          class="lg:w-1/2 lg:ml-10 p-4 bg-white rounded-md shadow-md -ml-4 text-center"
        >
          <h1>Planifikimi i Dasmës</h1>
          <p class="mb-4">
            Për të ju ndihmuar të gjeni pamjen e duhur për ceremoninë tuaj, kemi
            krijuar një gamë të mrekullueshme të paketave që mund të zgjidhni,
            ose mund t'i përshtatni çdo paketë në mënyrë të veçantë për të
            përmbushur të gjitha nevojat tuaja.
          </p>

          <!-- Add more content as needed -->
        </div>
      </div>
    </section>

    <section class="text-center">
      <!-- Gallery Content -->
      <div class="container mx-auto p-8">
        <h2 class="text-2xl font-bold mb-4">Galeri</h2>
        <!-- Your gallery images go here -->
        <!-- Example: -->
        <div
          class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
        >
          <img
            src="../assets/wedding1.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding2.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding3.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding4.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding5.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding6.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding7.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding8.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding9.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding12.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding11.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <img
            src="../assets/wedding10.jpg"
            alt=""
            class="w-full h-48 object-cover mb-4 rounded-md shadow-md"
          />
          <!-- Add more images as needed -->
        </div>
      </div>
    </section>
    <!-- Footer Section -->
    <footer class="bg-pink-50 p-8 text-center">
      <div
        class="max-w-6xl mx-auto flex flex-col lg:flex-row justify-center items-center"
      >
        <!-- Column 1: Company Logo and Name -->
        <div class="lg:w-1/4 mb-4 lg:mb-0 flex flex-col items-center">
          <div class="flex items-center mb-2">
            <img
              src="../assets/logo.jpg"
              alt="Logo"
              class="h-8 w-auto mr-2 rounded-full"
            />
            <div class="text-3xl font-bold">Tabaku Event</div>
          </div>
          <!-- Additional Company Info if needed -->
        </div>

        <!-- Column 2: Navigation Links -->
        <div class="lg:w-1/4 mb-4 lg:mb-0 font-mono">
          <h3 class="text-xl font-bold mb-2">Quick Links</h3>
          <ul>
            <li><a class="hover:text-blue-400" href="/home">Rreth nesh</a></li>
            <li>
              <a class="hover:text-blue-400" href="/service-page-1"
                >Sherbimet</a
              >
            </li>
            <li><a class="hover:text-blue-400" href="/contact">Kontakt</a></li>
          </ul>
        </div>

        <!-- Column 3: Contact Details -->
        <div class="lg:w-1/4 font-mono">
          <h3 class="text-xl font-bold mb-2">Kontakt</h3>
          <p>
            <i class="fas fa-envelope mr-2"></i> Email: info@tabakuevent.com
          </p>
          <p><i class="fas fa-phone-alt mr-2"></i> Phone: +355 696157649</p>
          <p><i class="fas fa-map-marker-alt mr-2"></i> Pajove, Elbasan</p>
        </div>
      </div>

      <!-- Additional styling if needed -->
    </footer>
  </div>
</template>

<script>
import backgroundImage from "../assets/pic.jpg";

export default {
  data() {
    return {
      backgroundImage,
      showDropDown: false,
      dropdownTimer: null,
    };
  },
  methods: {
    openDropdown() {
      clearTimeout(this.dropdownTimer);
      this.showDropDown = true;
    },
    closeDropdown() {
      this.dropdownTimer = setTimeout(() => {
        this.showDropDown = false;
      }, 1000); // Adjust the duration (in milliseconds) you want the dropdown to stay visible
    },
    keepDropdownOpen() {
      // Do nothing to keep the dropdown open when clicking on a service link
    },
  },
};
</script>

<style scoped>
/* Add component-specific styles here */
</style>
