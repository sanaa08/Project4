import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import "./style.css";
import App from "./App.vue";
import Home from "./pages/Home.vue";
import ServicePage1 from "./pages/ServicePage1.vue"; // Make sure the path is correct
import ServicePage2 from "./pages/ServicePage2.vue";
import ServicePage3 from "./pages/ServicePage3.vue";
import contact from "./pages/contact.vue";

const routes = [
  {
    path: "/home",
    name: "home",
    component: Home,
    meta: { requiresAuth: true },
  },
  {
    path: "/service-page-1", // You can customize the path
    name: "servicePage1",
    component: ServicePage1,
    meta: { requiresAuth: true },
  },
  {
    path: "/service-page-2", // You can customize the path
    name: "servicePage2",
    component: ServicePage2,
    meta: { requiresAuth: true },
  },
  {
    path: "/service-page-3", // You can customize the path
    name: "servicePage3",
    component: ServicePage3,
    meta: { requiresAuth: true },
  },
  {
    path: "/contact",
    name: "contact",
    component: contact,
    meta: { requiresAuth: true },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

createApp(App).use(router).mount("#app");
