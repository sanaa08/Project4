<template>
  <div>
    <!-- ... (rest of your component) ... -->
    <div class="instagram-post">
      <iframe
        :src="
          permalink +
          'https://www.instagram.com/p/CzOKlu1orjY/?utm_source=ig_embed&amp;utm_campaign=loading'
        "
        frameborder="0"
        allowfullscreen
      ></iframe>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    permalink: String,
    // ... (other props)
  },
};
</script>

<style scoped>
/* ... (your component styles) ... */
</style>
