const express = require("express");
const db = require("../dbconnection/dbconn.js");
const router = express.Router();

// API endpoint to save a message
const submitForm = (req, res) => {
  try {
    const { name, email, phoneNumber, message } = req.body;

    // Use the db connection to execute the query

    db.query(
      "INSERT INTO `web-app` (name, email, phoneNumber, message) VALUES (?, ?, ?, ?)",
      [name, email, phoneNumber, message],
      (error, results) => {
        if (error) {
          console.error(error);
          return res.status(500).send("Internal Server Error");
        } else {
          return res
            .status(201)
            .json({ message: "Message saved successfully" });
        }
      }
    );
  } catch (error) {
    console.error(error);
    return res.status(500).send("Internal Server Error");
  }
};

module.exports = { submitForm };
