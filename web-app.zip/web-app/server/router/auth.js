const express = require("express");
const { submitForm } = require("../controllers/auth.js");
const router = express.Router();

router.post("/contact/save-message", submitForm);

module.exports = router;
