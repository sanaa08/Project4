// const express = require("express");
// const cors = require("cors");

// const app = express();
// const port = 3001;

// app.use(express.json());
// app.use(cors());

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });
const express = require("express");
const cors = require("cors");
const authRoutes = require("./router/auth.js"); // Adjust the path accordingly

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());
app.use(cors());

// Include the auth routes
app.use("/api/auth", authRoutes);

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
